package tools;

/**
 * Created by Hugo on 29/04/2016.
 */
public abstract class Observer {
    public abstract void update(Object obj);
}
