package launcher.localLauncher;

import controler.ChessGameControlers;

import javax.swing.*;
import java.awt.*;

/**
 * Created by MSIgamer on 29/04/2016.
 */
public class ChessGameGUI extends JFrame {
    public ChessGameGUI(String s, ChessGameControlers chessGameControler, Dimension dim) {
    }
}
